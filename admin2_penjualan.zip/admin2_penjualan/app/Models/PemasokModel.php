<?php

namespace App\Models;

use CodeIgniter\Model;

class PemasokModel extends Model
{
    protected $table = 'pemasok';
    protected $primaryKey = 'id_pemasok';
    protected $allowedFields = ['id_pemasok', 'nama_pemasok', 'jenis_barang', 'alamat_pemasok', 'no_telepon'];

    public function getPemasok($id_pemasok = false)
    {
        if ($id_pemasok == false) {
            return $this->findAll();
        }
        return $this->where(['id_pemasok' => $id_pemasok])->first();
    }
}
