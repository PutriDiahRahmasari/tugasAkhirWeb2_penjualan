<?php

namespace App\Models;

use CodeIgniter\Model;

class EkspedisiModel extends Model
{
    protected $table = 'ekspedisi';
    protected $primaryKey = 'kd_ekspedisi';
    protected $allowedFields = ['kd_ekspedisi', 'nama_ekspedisi', 'alamat', 'kategory', 'satuan', 'harga'];

    public function getEkspedisi($kd_ekspedisi = false)
    {
        if ($kd_ekspedisi == false) {
            return $this->findAll();
        }
        return $this->where(['kd_ekspedisi' => $kd_ekspedisi])->first();
    }
}
