<?php

namespace App\Models;

use CodeIgniter\Model;

class BarangModel extends Model
{
    protected $table = 'barang';
    protected $primaryKey = 'kd_barang';
    protected $allowedFields = ['nama', 'harga', 'satuan', 'gambar', 'stok'];

    public function getBarang($kdbarang = false)
    {
        if ($kdbarang == false) {
            return $this->findAll();
        }
        return $this->where(['kd_barang' => $kdbarang])->first();
    }
}
