<?php
namespace App\Models;
use CodeIgniter\Model;

class userModel extends Model
{

    protected $table = 'user';
    protected $primarykey = 'id_user';
    protected $allowedfields = ['first_name','last_name','email_user','pass_user','kategory'];


}
?>