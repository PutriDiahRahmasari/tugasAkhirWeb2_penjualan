<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');
$routes->get('/dashboard', 'Home::dashboard', ['filter' => 'auth_login']);
$routes->post('val/login', 'Home::val_user');
$routes->get('logout', 'Home::logout_ac');

//Barang
$routes->get('/barang', 'Barang::index', ['filter' => 'auth_login']);
$routes->get('/barang/tambah', 'Barang::tambah', ['filter' => 'auth_login']);
$routes->post('/barang/simpan', 'Barang::simpan');
$routes->post('/barang/update/(:num)', 'Barang::update/$1');
$routes->delete('/barang/(:num)', 'Barang::hapus/$1');
$routes->get('/barang/ubah/(:num)', 'Barang::ubah/$1');
$routes->get('/barang/(:any)', 'Barang::detail/$1');
$routes->get('/tb_barang', 'Barang::tables_db');
$routes->get('/dt_barang', 'Barang::dt_barang');

//Ekspedisi
$routes->get('/ekspedisi', 'Ekspedisi::index', ['filter' => 'auth_login']);
$routes->get('/ekspedisi/tambah', 'Ekspedisi::tambah', ['filter' => 'auth_login']);
$routes->post('/ekspedisi/simpan', 'Ekspedisi::simpan');
$routes->post('/ekspedisi/update/(:num)', 'Ekspedisi::update/$1');
$routes->delete('/ekspedisi/(:num)', 'Ekspedisi::hapus/$1');
$routes->get('/ekspedisi/ubah/(:num)', 'Ekspedisi::ubah/$1');
$routes->get('/ekspedisi/(:any)', 'Ekspedisi::detail/$1');
$routes->get('/tb_ekspedisi', 'Ekspedisi::tables_db');
$routes->get('/dt_ekspedisi', 'Ekspedisi::dt_ekspedisi');


//Pemasok
$routes->get('/pemasok', 'Pemasok::index', ['filter' => 'auth_login']);
$routes->get('/Pemasok/tambah', 'Pemasok::tambah', ['filter' => 'auth_login']);
$routes->post('/Pemasok/simpan', 'Pemasok::simpan');
$routes->post('/pemasok/update/(:num)', 'Pemasok::update/$1');
$routes->delete('/Pemasok/(:num)', 'Pemasok::hapus/$1');
$routes->get('/Pemasok/ubah/(:num)', 'Pemasok::ubah/$1');
$routes->get('/pemasok/(:any)', 'Pemasok::detail/$1');
$routes->get('/tb_pemasok', 'Pemasok::tables_db');
$routes->get('/dt_pemasok', 'Pemasok::dt_pemasok');


//Pelanggan
$routes->get('/pelanggan', 'Pelanggan::index', ['filter' => 'auth_login']);
$routes->get('/pelanggan/tambah', 'Pelanggan::tambah', ['filter' => 'auth_login']);
$routes->post('/pelanggan/simpan', 'Pelanggan::simpan');
$routes->post('/pelanggan/update/(:num)', 'Pelanggan::update/$1');
$routes->delete('/pelanggan/(:num)', 'Pelanggan::hapus/$1');
$routes->get('/pelanggan/ubah/(:num)', 'Pelanggan::ubah/$1');
$routes->get('/pelanggan/(:any)', 'Pelanggan::detail/$1');
$routes->get('/tb_pelanggan', 'Pelanggan::tables_db');
$routes->get('/dt_pelanggan', 'Pelanggan::dt_pelanggan');
