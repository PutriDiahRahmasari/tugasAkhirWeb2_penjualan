<?php

namespace App\Controllers;

use App\Models\PelangganModel;

class Pelanggan extends BaseController
{
    public $PelangganModel;
    public function __construct()
    {
        $this->PelangganModel = new PelangganModel();
    }

    public function index()
    {
        $data = [
            'title' => 'Daftar Pelanggan',
            'pelanggan' => $this->PelangganModel->getPelanggan()
        ];
        return view('pelanggan/index', $data);
    }

    public function detail($id_pelanggan)
    {
        $data = [
            'title' => 'Detail Pelanggan',
            'Pelanggan' => $this->PelangganModel->getPelanggan($id_pelanggan)
        ];
        return view('pelanggan/detail', $data);
    }


    public function tambah()
    {
        //mengambil data input saat melakukan validasi
        session();
        $data = [
            'title' => 'Tambah pelanggan',
            'validation' => \Config\Services::validation()
        ];

        return view('pelanggan/tambah', $data);
    }

    public function simpan()
    {
        //validasi input data
        if (!$this->validate([
            'nama_pelanggan' => [
                'rules' => 'required|is_unique[pelanggan.nama_pelanggan]',
                'errors' => [
                    'required' => '{field} pelanggan wajib di isi',
                    'is_unique' => '{field} pelanggan sudah ada'
                ]
            ]
        ])) {

            //menampilkan pesan kesalahan
            $validation = \Config\Services::validation();

            return redirect()->to('/pelanggan/tambah')->withInput()->with('validation', $validation);
        }

        $this->PelangganModel->save([
            'nama_pelanggan' => $this->request->getVar('nama_pelanggan'),
            'jenis_pembayaran' => $this->request->getVar('jenis_pembayaran'),
            'alamat_pelanggan' => $this->request->getVar('alamat_pelanggan'),
            'no_hp' => $this->request->getVar('no_hp'),
            'tanggal' => $this->request->getVar('tanggal'),
        ]);

        //flash pesan disimpan
        session()->setFlashdata('pesan', 'Data sudah berhasil di tambahkan');

        return redirect()->to('/pelanggan');
    }

    public function hapus($id_pelanggan)
    {
        $this->PelangganModel->delete($id_pelanggan);

        //flashdata pesan dihapus
        session()->setFlashdata('pesan', 'Data Anda Sudah Hilang!');

        return redirect()->to('/pelanggan');
    }

    public function ubah($id_pelanggan)
    {
        //mengambil data input saat melakukan validasi
        session();
        $data = [
            'title' => 'Ubah Data Pelanggan',
            'validation' => \Config\Services::validation(),
            'pelanggan' => $this->PelangganModel->getPelanggan($id_pelanggan)
        ];

        return view('pelanggan/ubah', $data);
    }

    public function update($id_pelanggan)
    {
        $this->PelangganModel->update($id_pelanggan, [
            'nama_pelanggan' => $this->request->getVar('nama_pelanggan'),
            'jenis_pembayaran' => $this->request->getVar('jenis_pembayaran'),
            'alamat_pelanggan' => $this->request->getVar('alamat_pelanggan'),
            'no_hp' => $this->request->getVar('no_hp'),
            'tanggal' => $this->request->getVar('tanggal')
        ]);

        //flashdata pesan disimpan
        session()->setFlashdata('pesan', 'Data Sudah Di Rubah Ya!');

        return redirect()->to('/pelanggan');
    }

    public function tables_db()
    {
        $val_pelanggan = new PelangganModel();
        $session_lg = session();
        $data = [
            'nama' => $session_lg->get('nama_pelanggan'),
            'dt_pelanggan' => $val_pelanggan->findAll(),

        ];
        return view('/pelanggan/tables_pelanggan', $data);
    }
    public function dt_pelanggan()
    {
        $val_pelanggan = new PelangganModel();
        $data = $val_pelanggan->findAll();
        return json_encode($data);
    }
}
