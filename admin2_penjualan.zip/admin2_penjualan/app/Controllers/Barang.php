<?php

namespace App\Controllers;

use App\Models\BarangModel;

class Barang extends BaseController
{
    public $BarangModel;
    public function __construct()
    {
        $this->BarangModel = new BarangModel();
    }

    public function index()
    {
        $data = [
            'title' => 'Daftar Barang',
            'barang' => $this->BarangModel->getBarang()
        ];
        return view('barang/index', $data);
    }


    public function tambah()
    {
        //mengambil data input saat melakukan validasi
        session();
        $data = [
            'title' => 'Tambah Barang',
            'validation' => \Config\Services::validation()
        ];

        return view('barang/tambah', $data);
    }

    public function detail($kd_barang)
    {
        $data = [
            'title' => 'Detail Barang',
            'barang' => $this->BarangModel->getBarang($kd_barang)
        ];
        return view('barang/detail', $data);
    }

    public function simpan()
    {
        //validasi input data
        if (!$this->validate([
            'nama' => [
                'rules' => 'required|is_unique[barang.nama]',
                'errors' => [
                    'required' => '{field} barang wajib di isi',
                    'is_unique' => '{field} barang sudah ada'
                ]
            ]
        ])) {

            //menampilkan pesan kesalahan
            $validation = \config\Services::validation();

            return redirect()->to('/barang/tambah')->withInput()->with('validation', $validation);
        }

        $this->BarangModel->save([
            'nama' => $this->request->getVar('nama'),
            'harga' => $this->request->getVar('harga'),
            'satuan' => $this->request->getVar('satuan'),
            'gambar' => $this->request->getVar('gambar'),
            'stok' => $this->request->getVar('stok'),
        ]);

        //flash pesan disimpan
        session()->setFlashdata('pesan', 'Data sudah berhasil di tambahkan');

        return redirect()->to('/barang');
    }

    public function hapus($kdbarang)
    {
        $this->BarangModel->delete($kdbarang);

        //flashdata pesan dihapus
        session()->setFlashdata('pesan', 'Data Anda Sudah Hilang!');

        return redirect()->to('/barang');
    }

    public function ubah($kdbarang)
    {
        //mengambil data input saat melakukan validasi
        session();
        $data = [
            'title' => 'Ubah Data Barang',
            'validation' => \Config\Services::validation(),
            'barang' => $this->BarangModel->getBarang($kdbarang)
        ];

        return view('barang/ubah', $data);
    }

    public function update($kdbarang)
    {
        $this->BarangModel->update($kdbarang, [
            'nama' => $this->request->getVar('nama'),
            'harga' => $this->request->getVar('harga'),
            'satuan' => $this->request->getVar('satuan'),
            'gambar' => $this->request->getVar('gambar'),
            'stok' => $this->request->getVar('stok'),
        ]);

        //flashdata pesan disimpan
        session()->setFlashdata('pesan', 'Data Barang Sudah Di Rubah Ya!');

        return redirect()->to('/barang');
    }

    public function tables_db()
    {
        $val_barang = new BarangModel();
        $session_lg = session();
        $data = [
            'nama' => $session_lg->get('nama'),
            'dt_barang' => $val_barang->findAll(),

        ];
        return view('/barang/tables_barang', $data);
    }
    public function dt_barang()
    {
        $val_barang = new BarangModel();
        $data = $val_barang->findAll();
        return json_encode($data);
    }
}
