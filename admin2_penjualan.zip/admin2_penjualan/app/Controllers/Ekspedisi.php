<?php

namespace App\Controllers;

use App\Models\EkspedisiModel;

class Ekspedisi extends BaseController
{
    public $EkspedisiModel;
    public function __construct()
    {
        $this->EkspedisiModel = new EkspedisiModel();
    }

    public function index()
    {
        $data = [
            'title' => 'Daftar Ekspedisi',
            'ekspedisi' => $this->EkspedisiModel->getEkspedisi()
        ];
        return view('ekspedisi/index', $data);
    }

    public function detail($kd_ekspedisi)
    {
        $data = [
            'title' => 'Detail Ekspedisi',
            'ekspedisi' => $this->EkspedisiModel->getEkspedisi($kd_ekspedisi)
        ];
        return view('ekspedisi/detail', $data);
    }

    public function tambah()
    {
        //mengambil data input saat melakukan validasi
        session();
        $data = [
            'title' => 'Tambah Ekspedisi',
            'validation' => \Config\Services::validation()
        ];

        return view('ekspedisi/tambah', $data);
    }

    public function simpan()
    {
        //validasi input data
        if (!$this->validate([
            'nama_ekspedisi' => [
                'rules' => 'required|is_unique[ekspedisi.nama_ekspedisi]',
                'errors' => [
                    'required' => '{field} ekspedisi wajib di isi',
                    'is_unique' => '{field} ekspedisi sudah ada'
                ]
            ]
        ])) {
            $validation = \Config\Services::validation();

            return redirect()->to('/ekspedisi/tambah')->withInput()->with('validation', $validation);
        }

        $this->EkspedisiModel->save([
            'nama_ekspedisi' => $this->request->getVar('nama_ekspedisi'),
            'alamat' => $this->request->getVar('alamat'),
            'kategory' => $this->request->getVar('kategory'),
            'satuan' => $this->request->getVar('satuan'),
            'harga' => $this->request->getVar('harga'),
        ]);

        //flash pesan disimpan
        session()->setFlashdata('pesan', 'Data sudah berhasil di tambahkan');

        return redirect()->to('/ekspedisi');
    }

    public function hapus($kd_ekspedisi)
    {
        $this->EkspedisiModel->delete($kd_ekspedisi);

        //flashdata pesan dihapus
        session()->setFlashdata('pesan', 'Data Anda Sudah Hilang!');

        return redirect()->to('/ekspedisi');
    }

    public function ubah($kd_ekspedisi)
    {
        //mengambil data input saat melakukan validasi
        session();
        $data = [
            'title' => 'Ubah Data Ekspedisi',
            'validation' => \Config\Services::validation(),
            'ekspedisi' => $this->EkspedisiModel->getEkspedisi($kd_ekspedisi)
        ];

        return view('ekspedisi/ubah', $data);
    }

    public function update($kd_ekspedisi)
    {
        $this->EkspedisiModel->update($kd_ekspedisi, [
            'nama_ekspedisi' => $this->request->getVar('nama_ekspedisi'),
            'alamat' => $this->request->getVar('alamat'),
            'kategory' => $this->request->getVar('kategory'),
            'satuan' => $this->request->getVar('satuan'),
            'harga' => $this->request->getVar('harga')
        ]);

        //flashdata pesan disimpan
        session()->setFlashdata('pesan', 'Data Sudah Di Rubah Ya!');

        return redirect()->to('/ekspedisi');
    }

    public function tables_db()
    {
        $val_ekspedisi = new EkspedisiModel();
        $session_lg = session();
        $data = [
            'nama' => $session_lg->get('nama_ekspedisi'),
            'dt_ekspedisi' => $val_ekspedisi->findAll(),

        ];
        return view('/ekspedisi/tables_ekspedisi', $data);
    }
    public function dt_ekspedisi()
    {
        $val_ekspedisi = new EkspedisiModel();
        $data = $val_ekspedisi->findAll();
        return json_encode($data);
    }
}
