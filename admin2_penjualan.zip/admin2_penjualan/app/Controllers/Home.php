<?php

namespace App\Controllers;

use App\Models\UserModel;

class Home extends BaseController
{
    public function index(): string
    {
        helper(['form']);
        return view('login');
    }

    public function val_user()
    {
        $session_lg = session();
        $val_user = new UserModel();
        $email_user = $this->request->getVar('email_user');
        $pass_user = $this->request->getVar('pass_user');
        $kat_user = $this->request->getVar('kat_user');
        $data = $val_user->where('email_user', $email_user)->first();
        if ($data) {
            //echo "data di temukan";
            if ($data['pass_user'] == $pass_user && $data['kategory'] == $kat_user) {
                // echo "password dan email benar";
                $ses_data = [
                    'email_user' => $data['email_user'],
                    'first_name' => $data['first_name'],
                    'last_name' => $data['last_name'],
                    'kategory' => $data['kategory'],
                    'loged_in' => true
                ];
                $session_lg->set($ses_data);
                return redirect()->to('/dashboard');
            } else {
                echo "password salah dan email benar";
                return redirect()->to('/');
            }
        } else {
            echo "data tidak di temukan";
            return redirect()->to('/');
        }
    }

    public function dashboard()
    {
        $session_lg = session();
        $data =
            [
                // untuk mengambil first_name
                'nama' => $session_lg->get('first_name'),
            ];
        return view('dashboard', $data);
    }

    public function logout_ac()
    {
        $session_lg = session();
        $session_lg->destroy();
        return redirect()->to('/');
    }
}
