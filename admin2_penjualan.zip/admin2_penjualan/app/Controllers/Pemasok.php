<?php

namespace App\Controllers;

use App\Models\PemasokModel;

class Pemasok extends BaseController
{
    public $PemasokModel;
    public function __construct()
    {
        $this->PemasokModel = new PemasokModel();
    }

    public function index()
    {
        $data = [
            'title' => 'Daftar Pemasok',
            'Pemasok' => $this->PemasokModel->getPemasok()
        ];
        return view('Pemasok/index', $data);
    }

    public function detail($id_pemasok)
    {
        $data = [
            'title' => 'Detail Pemasok',
            'Pemasok' => $this->PemasokModel->getPemasok($id_pemasok)
        ];
        return view('Pemasok/detail', $data);
    }

    public function tambah()
    {
        //mengambil data input saat melakukan validasi
        session();
        $data = [
            'title' => 'Tambah Pemasok',
            'validation' => \Config\Services::validation()
        ];

        return view('Pemasok/tambah', $data);
    }

    public function simpan()
    {
        //validasi input data
        if (!$this->validate([
            'nama_pemasok' => [
                'rules' => 'required|is_unique[pemasok.nama_pemasok]',
                'errors' => [
                    'required' => '{field} Pemasok wajib di isi',
                    'is_unique' => '{field} Pemasok sudah ada'
                ]
            ]
        ])) {

            //menampilkan pesan kesalahan
            $validation = \Config\Services::validation();

            return redirect()->to('/pemasok/tambah')->withInput()->with('validation', $validation);
        }

        $this->PemasokModel->save([
            'nama_pemasok' => $this->request->getVar('nama_pemasok'),
            'jenis_barang' => $this->request->getVar('jenis_barang'),
            'alamat_pemasok' => $this->request->getVar('alamat_pemasok'),
            'no_telepon' => $this->request->getVar('no_telepon'),
        ]);

        //flash pesan disimpan
        session()->setFlashdata('pesan', 'Data sudah berhasil di tambahkan');

        return redirect()->to('/pemasok');
    }

    public function hapus($id_pemasok)
    {
        $this->PemasokModel->delete($id_pemasok);

        //flashdata pesan dihapus
        session()->setFlashdata('pesan', 'Data Anda Sudah Hilang!');

        return redirect()->to('/pemasok');
    }

    public function ubah($id_pemasok)
    {
        //mengambil data input saat melakukan validasi
        session();
        $data = [
            'title' => 'Ubah Data Pemasok',
            'validation' => \Config\Services::validation(),
            'Pemasok' => $this->PemasokModel->getPemasok($id_pemasok)
        ];

        return view('pemasok/ubah', $data);
    }

    public function update($id_pemasok)
    {
        $this->PemasokModel->update($id_pemasok, [
            'nama_pemasok' => $this->request->getVar('nama_pemasok'),
            'jenis_barang' => $this->request->getVar('jenis_barang'),
            'alamat_pemasok' => $this->request->getVar('alamat_pemasok'),
            'no_telepon' => $this->request->getVar('no_telepon')
        ]);

        //flashdata pesan disimpan
        session()->setFlashdata('pesan', 'Data Sudah Di Rubah Ya!');

        return redirect()->to('/pemasok');
    }
    public function tables_db()
    {
        $val_pemasok = new PemasokModel();
        $session_lg = session();
        $data = [
            'nama' => $session_lg->get('nama_pemasok'),
            'dt_pemasok' => $val_pemasok->findAll(),

        ];
        return view('/pemasok/tables_pemasok', $data);
    }
    public function dt_pemasok()
    {
        $val_pemasok = new PemasokModel();
        $data = $val_pemasok->findAll();
        return json_encode($data);
    }
}
