<?php

namespace App\Filters;

use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponsableInterface;
use CodeIgniter\Filters\FilterInterface;

class Auth_Login implements FilterInterface
{
    public function before(RequestInterface $request, $arguments = null)
    {
        $session_lg = session();
        if (!$session_lg->get('loged_in')) {
            return redirect()->to('/');
        }
    }

    public function after(RequestInterface $request, \CodeIgniter\HTTP\ResponseInterface $response, $arguments = null)
    {
        //
    }
}
