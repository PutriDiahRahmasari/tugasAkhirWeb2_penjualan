<?php $this->extend('dashboard'); ?>
<?php $this->section('content'); ?>
<div class="bg-light" style="padding-bottom: 14.9%;">
    <div class="container pt-5">
        <div class="row">
            <div class="col">
                <h2 class="text-dark pt-3">Form Ubah Data Pelanggan</h2>
                <hr>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="col">
            <form action="/pelanggan/update/<?= $pelanggan['id_pelanggan']; ?>" method="post" class="text-light">
                <?= csrf_field(); ?>
                <div class="row mb-3">
                    <label for="nama_pelanggan" class="col-sm-2 col-form-label text-dark">Nama Pelanggan</label>
                    <div class="col-sm-6">
                        <input type="text" class="form-control
                    <?= ($validation->hasError('nama_pelanggan')) ? 'is-invalid' : ''; ?>" id="nama_pelanggan" name="nama_pelanggan" autofocus value="<?= $pelanggan['nama_pelanggan']; ?>">
                        <div id="nama_pelangganFeedback" class="invalid-feedback">
                            <?= $validation->getError('nama_pelanggan'); ?>
                        </div>
                    </div>
                </div>
                <div class="row mb-3">
                    <label for="jenis_pembayaran" class="col-sm-2 col-form-label text-dark">Jenis Pembayaran</label>
                    <div class="col-sm-6">
                        <input type="text" class="form-control" id="jenis_pembayaran" name="jenis_pembayaran" value="<?= $pelanggan['jenis_pembayaran']; ?>">
                    </div>
                </div>
                <div class="row mb-3">
                    <label for="alamat_pelanggan" class="col-sm-2 col-form-label text-dark">Alamat Pelanggan</label>
                    <div class="col-sm-6">
                        <input type="text" class="form-control" id="alamat_pelanggan" name="alamat_pelanggan" value="<?= $pelanggan['alamat_pelanggan']; ?>">
                    </div>
                </div>
                <div class="row mb-3">
                    <label for="no_hp" class="col-sm-2 col-form-label text-dark">No HP</label>
                    <div class="col-sm-6">
                        <input type="text" class="form-control" id="no_hp" name="no_hp" value="<?= $pelanggan['no_hp']; ?>">
                    </div>
                </div>
                <div class="row mb-3">
                    <label for="tanggal" class="col-sm-2 col-form-label text-dark">Tanggal</label>
                    <div class="col-sm-6">
                        <input type="text" class="form-control" id="tanggal" name="tanggal" value="<?= $pelanggan['tanggal']; ?>">
                    </div>
                </div>
                <button type="submit" class="btn btn-primary">Ubah Data</button>
            </form>
        </div>
    </div>
</div>
<?php $this->endSection(); ?>