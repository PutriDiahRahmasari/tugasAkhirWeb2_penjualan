<?php $this->extend('dashboard'); ?>
<?php $this->section('content'); ?>
<div class="bg-light" styles="margin: 0;" style="padding-bottom: 14%;">
    <div class="container-fluid ">
        <div class="bg-light">
            <div class="container pt-5">
                <div class="row">
                    <div class="col">
                        <h2 class="text-dark pt-3">Detail Data Pelanggan</h2>
                    </div>
                </div>
            </div>
            <div class="card mb-3 bg-dark text-light" style="max-width: 540px;">
                <div class="row g-0">
                    <div class="col-md-8">
                        <div class="card-body">
                            <h5 class="card-title"><b>Id Pelanggan: <?= $Pelanggan['id_pelanggan']; ?></b></h5>
                            <p class="card-text"><b>Nama Pelanggan: <?= $Pelanggan['nama_pelanggan']; ?></b></p>
                            <p class="card-text"><b>Jenis pembayaran : <?= $Pelanggan['jenis_pembayaran']; ?></b></p>
                            <p class="card-text"><b>Alamat Pelanggan: <?= $Pelanggan['alamat_pelanggan']; ?></b></p>
                            <p class="card-text"><b>No Hp: <?= $Pelanggan['no_hp']; ?></b></p>
                            <a href="/pelanggan" class="btn btn-light">Kembali</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
</div>
</div>

<?php $this->endSection(); ?>