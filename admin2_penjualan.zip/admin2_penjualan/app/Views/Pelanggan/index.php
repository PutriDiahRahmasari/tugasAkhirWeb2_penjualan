<?php $this->extend('dashboard'); ?>
<?php $this->section('content'); ?>


<div class="bg-light">
    <div class="container text-center pt-5">
        <div class="row">
            <div class="col">
                <img src="/Images/user.png" alt="" width="15%" />
                <h2 class="text-dark pt-3">Daftar Pelanggan</h2>
            </div>
        </div>
    </div>

    <!-- button tambah   -->
    <div class="container text-center mt-3">
        <div class="text-dark pt-3">
            <?php if (session()->getFlashdata('pesan')) : ?>
                <div class="alert alert-succes" role="alert">
                    <?= session()->getFlashdata('pesan'); ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
    <!-- daftar pelanggan -->
    <div class="container text-center pt-5 pb-5">
        <div class="col">
            <div class="container">
                <div class="card text-center">
                    <div class="card-body bg-dark ">
                        <table class="table text-light bg-dark" border="1">
                            <thead>
                                <tr>
                                    <th scope="col">Id Pelanggan</th>
                                    <th scope="col">Nama Pelanggan</th>
                                    <th scope="col">Jenis Pembayaran</th>
                                    <th scope="col">Tanggal</th>
                                    <th scope="col">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $i = 1;
                                foreach ($pelanggan as $plg) :
                                ?>
                                    <tr>
                                        <td><?= $plg['id_pelanggan']; ?></td>
                                        <td><?= $plg['nama_pelanggan']; ?></td>
                                        <td><?= $plg['jenis_pembayaran']; ?></td>
                                        <td><?= $plg['tanggal']; ?></td>
                                        <td>
                                            <a href="/pelanggan/<?= $plg['id_pelanggan']; ?>" class="btn btn-success">Detail</a>
                                            <a href="/pelanggan/ubah/<?= $plg['id_pelanggan']; ?>" class="btn btn-primary">Ubah</i></a>
                                            <form action="/pelanggan/<?= $plg['id_pelanggan']; ?>" method="post" class="d-inline">
                                                <?= csrf_field(); ?>
                                                <input type="hidden" name="_method" value="DELETE">
                                                <button type="submit" class="btn btn-danger" onclick="return confirm('Yakin Mau Menghapus Data Ini !!!')">Hapus</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div><br><br>
            </div>
        </div>
    </div>
</div>
<!-- end daftar pelanggan -->
<?php $this->endSection(); ?>