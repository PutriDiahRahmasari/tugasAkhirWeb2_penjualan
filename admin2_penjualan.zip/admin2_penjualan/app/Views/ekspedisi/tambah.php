<?php $this->extend('dashboard'); ?>
<?php $this->section('content'); ?>
<div class="bg-light" style="padding-bottom: 14%;">
    <div class="container-fluid">

        <div class="container pt-5">
            <div class="row">
                <div class="col">
                    <h2 class="text-dark pt-3">Form Tambah Data Ekspedisi</h2>
                    <hr>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="col">
                <!-- menampilkan validasi -->
                <?= $validation->listErrors(); ?>

                <form action="/ekspedisi/simpan" method="post" class="text-light">
                    <?= csrf_field(); ?>
                    <div class="row mb-3">
                        <label for="nama_ekspedisi" class="col-sm-2 col-form-label text-dark">Nama Ekspedisi</label>
                        <div class="col-sm-6">
                            <input type="text" class="form-control
                    <?= ($validation->hasError('nama_ekspedisi')) ? 'is-invalid' : ''; ?>" id="nama_ekspedisi" name="nama_ekspedisi" autofocus value="<?= old('nama_ekspedisi'); ?>">
                            <div id="nama_ekspedisiFeedback" class="invalid-feedback">
                                <?= $validation->getError('nama_ekspedisi'); ?>
                            </div>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <label for="alamat" class="col-sm-2 col-form-label text-dark">Alamat</label>
                        <div class="col-sm-6">
                            <input type="text" class="form-control" id="alamat" name="alamat">
                        </div>
                    </div>
                    <div class="row mb-3">
                        <label for="kategory" class="col-sm-2 col-form-label text-dark">Kategory</label>
                        <div class="col-sm-6">
                            <input type="text" class="form-control" id="kategory" name="kategory">
                        </div>
                    </div>
                    <div class="row mb-3">
                        <label for="satuan" class="col-sm-2 col-form-label text-dark">Satuan</label>
                        <div class="col-sm-6">
                            <input type="text" class="form-control" id="satuan" name="satuan">
                        </div>
                    </div>
                    <div class="row mb-3">
                        <label for="harga" class="col-sm-2 col-form-label text-dark">Ongkir</label>
                        <div class="col-sm-6">
                            <input type="text" class="form-control" id="harga" name="harga">
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary">Simpan Data</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $this->endSection(); ?>