<?php $this->extend('dashboard'); ?>
<?php $this->section('content'); ?>


<!-- Begin Page Content -->
<div class="bg-light" styles="margin: 0;" style="padding-bottom: 14%;">
    <div class="container-fluid ">
        <div class="bg-light">
            <div class="container text-center pt-5">
                <div class="row">
                    <div class="col">
                        <h2 class="text-dark pt-3">Daftar Ekspedisi</h2>
                    </div>
                </div>
            </div>

            <!-- button tambah   -->
            <div class="container text-center mt-3">
                <div class="text-dark pt-3">
                    <?php if (session()->getFlashdata('pesan')) : ?>
                        <div class="alert alert-succes" role="alert">
                            <?= session()->getFlashdata('pesan'); ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            <!-- daftar ekspedisi -->

            <div class="container text-center">
                <div class="col">
                    <div class="container">
                        <div class="card text-center">
                            <div class="card-body bg-dark">
                                <table class="table bg-dark text-light" border="1">
                                    <thead>
                                        <tr class="text-light">
                                            <th scope="col">Kode</th>
                                            <th scope="col">Nama Ekspedisi</th>
                                            <th scope="col">Kategory</th>
                                            <th scope="col">Ongkir</th>
                                            <th scope="col">Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $i = 1;
                                        foreach ($ekspedisi as $e) :
                                        ?>
                                            <tr class="text-light">
                                                <td><?= $e['kd_ekspedisi']; ?></td>
                                                <td><?= $e['nama_ekspedisi']; ?></td>
                                                <td><?= $e['kategory']; ?></td>
                                                <td><?= $e['harga']; ?></td>
                                                <td>
                                                    <a href="/ekspedisi/<?= $e['kd_ekspedisi']; ?>" class="btn btn-success">Detail</a>
                                                    <a href="/ekspedisi/ubah/<?= $e['kd_ekspedisi']; ?>" class="btn btn-primary">Ubah</a>
                                                    <form action="/ekspedisi/<?= $e['kd_ekspedisi']; ?>" method="post" class="d-inline">
                                                        <?= csrf_field(); ?>
                                                        <input type="hidden" name="_method" value="DELETE">
                                                        <button type="submit" class="btn btn-danger" onclick="return confirm('Yakin Mau Menghapus Data Ini !!!')">Hapus</button>
                                                    </form>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div><br><br>
                    </div>
                </div>
            </div>
        </div>
        <!-- end daftar ekspedisi -->
        <?php $this->endSection(); ?>