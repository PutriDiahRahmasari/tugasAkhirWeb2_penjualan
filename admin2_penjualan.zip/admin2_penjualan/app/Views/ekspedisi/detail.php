<?php $this->extend('dashboard'); ?>
<?php $this->section('content'); ?>

<div class="bg-light" styles="margin: 0;" style="padding-bottom: 14%;">
    <div class="container-fluid ">
        <div class="bg-light">
            <div class="container pt-5">
                <div class="row">
                    <div class="col">
                        <h2 class="text-dark pt-3">Detail Data Ekspedisi</h2>
                    </div>
                </div>
            </div>
            <div class="card mb-3 bg-dark text-light" style="max-width: 540px;">
                <div class="row g-0">
                    <div class="col-md-8">
                        <div class="card-body">
                            <h5 class="card-title"><b>Kode Ekspedisi: <?= $ekspedisi['kd_ekspedisi']; ?></b></h5>
                            <p class="card-text"><b>Nama Ekspedisi: <?= $ekspedisi['nama_ekspedisi']; ?></b></p>
                            <p class="card-text"><b>Alamat: <?= $ekspedisi['alamat']; ?></b></p>
                            <p class="card-text"><b>Kategori: <?= $ekspedisi['kategory']; ?></b></p>
                            <p class="card-text"><b>Satuan: <?= $ekspedisi['satuan']; ?></b></p>
                            <p class="card-text"><b>Ongkir: <?= $ekspedisi['harga']; ?></b></p>
                            <a href="/ekspedisi" class="btn btn-light">Kembali</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<?php $this->endSection(); ?>