<?php $this->extend('/dashboard'); ?>
<?php $this->section('content'); ?>
<div class="bg-light" styles="margin: 0;" style="padding-bottom: 14%;">
    <div class="container-fluid ">
        <div class="bg-light">
            <div class="container pt-5">
                <div class="row">
                    <div class="col">
                        <h2 class="text-dark pt-3">Detail Data Barang</h2>
                    </div>
                </div>
            </div>
            <div class="card mb-3 bg-dark text-light" style="max-width: 540px;">
                <div class="row g-0">
                    <div class="col-md-4">
                        <img src="/img/<?= $barang['gambar']; ?>" alt="" width="200">
                    </div>
                    <div class="col-md-8">
                        <div class="card-body">
                            <h5 class="card-title"><b>Kode Barang: <?= $barang['kd_barang']; ?></b></h5>
                            <p class="card-text"><b>Nama Barang: <?= $barang['nama']; ?></b></p>
                            <p class="card-text"><b>Harga Barang: <?= $barang['harga']; ?></b></p>
                            <p class="card-text"><b>Satuan: <?= $barang['satuan']; ?></b></p>
                            <p class="card-text"><b>Stok: <?= $barang['stok']; ?></b></p>
                            <a href="/barang" class="btn btn-light">Kembali</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $this->endSection(); ?>