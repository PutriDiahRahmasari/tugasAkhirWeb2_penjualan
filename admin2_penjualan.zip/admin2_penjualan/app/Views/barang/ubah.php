<?php $this->extend('/dashboard'); ?>
<?php $this->section('content'); ?>
<div class="bg-light" styles="margin: 0;" style="padding-bottom: 14%;">
    <div class="container-fluid ">


        <div class="container pt-5">
            <div class="row">
                <div class="col">
                    <h2 class="text-dark pt-3">Form Ubah Data Barang</h2>
                    <hr>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="col">
                <form action="/barang/update/<?= $barang['kd_barang']; ?>" method="post" class="text-light">
                    <?= csrf_field(); ?>
                    <div class="row mb-3 ">
                        <label for="nama" class="col-sm-2 col-form-label text-dark">Nama</label>
                        <div class="col-sm-6">
                            <input type="text" class="form-control
                    <?= ($validation->hasError('nama')) ? 'is-invalid' : ''; ?>" id="nama" name="nama" autofocus value="<?= $barang['nama']; ?>">
                            <div id="namaFeedback" class="invalid-feedback">
                                <?= $validation->getError('nama'); ?>
                            </div>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <label for="harga" class="col-sm-2 col-form-label text-dark">Harga</label>
                        <div class="col-sm-6">
                            <input type="text" class="form-control" id="harga" name="harga" value="<?= $barang['harga']; ?> ">
                        </div>
                    </div>
                    <div class="row mb-3">
                        <label for="satuan" class="col-sm-2 col-form-label text-dark">Satuan</label>
                        <div class="col-sm-6">
                            <input type="text" class="form-control" id="satuan" name="satuan" value="<?= $barang['satuan']; ?>">
                        </div>
                    </div>
                    <div class="row mb-3">
                        <label for="gambar" class="col-sm-2 col-form-label text-dark">Gambar</label>
                        <div class="col-sm-6">
                            <input type="text" class="form-control" id="gambar" name="gambar" value="<?= $barang['gambar']; ?>">
                        </div>
                    </div>
                    <div class="row mb-3">
                        <label for="stok" class="col-sm-2 col-form-label text-dark">Stok</label>
                        <div class="col-sm-6">
                            <input type="text" class="form-control" id="stok" name="stok" value="<?= $barang['stok']; ?>">
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary">Ubah Data</button>
                </form>
            </div>
        </div>
        <?php $this->endSection(); ?>