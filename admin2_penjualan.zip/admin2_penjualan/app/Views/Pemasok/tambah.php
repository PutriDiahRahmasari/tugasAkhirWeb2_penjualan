<?php $this->extend('dashboard'); ?>
<?php $this->section('content'); ?>
<div class="bg-light" style="padding-bottom: 18%;">
    <div class="container-fluid">

        <div class="container pt-5">
            <div class="row">
                <div class="col">
                    <h2 class="text-dark pt-3">Form Tambah Data Pemasok</h2>
                    <hr>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="col">
                <!-- menampilkan validasi -->
                <?= $validation->listErrors(); ?>

                <form action="/Pemasok/simpan" method="post" class="text-light">
                    <?= csrf_field(); ?>
                    <div class="row mb-3">
                        <label for="nama_pemasok" class="col-sm-2 col-form-label text-dark">Nama Pemasok</label>
                        <div class="col-sm-6">
                            <input type="text" class="form-control
                    <?= ($validation->hasError('nama_pemasok')) ? 'is-invalid' : ''; ?>" id="nama_pemasok" name="nama_pemasok" autofocus value="<?= old('nama_pemasok'); ?>">
                            <div id="nama_pemasokFeedback" class="invalid-feedback">
                                <?= $validation->getError('nama_pemasok'); ?>
                            </div>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <label for="jenis_barang" class="col-sm-2 col-form-label text-dark">Jenis Barang</label>
                        <div class="col-sm-6">
                            <input type="text" class="form-control" id="jenis_barang" name="jenis_barang">
                        </div>
                    </div>
                    <div class="row mb-3">
                        <label for="alamat_pemasok" class="col-sm-2 col-form-label text-dark">Alamat Pemasok</label>
                        <div class="col-sm-6">
                            <input type="text" class="form-control" id="alamat_pemasok" name="alamat_pemasok">
                        </div>
                    </div>
                    <div class="row mb-3">
                        <label for="no_telepon" class="col-sm-2 col-form-label text-dark">No Telepon</label>
                        <div class="col-sm-6">
                            <input type="text" class="form-control" id="no_telepon" name="no_telepon">
                        </div>
                    </div>
            </div>
            <button type="submit" class="btn btn-primary">Simpan Data</button>
            </form>
        </div>
    </div>
</div>
<?php $this->endSection(); ?>