<?php $this->extend('dashboard'); ?>
<?php $this->section('content'); ?>


<div class="bg-light">
    <div class="container-fluid">
        <div class="bg-light pb-5">
            <div class="container text-center ">
                <div class="row">
                    <div class="col">
                        <h2 class="text-dark pt-5">Daftar Pemasok</h2>
                    </div>
                </div>
            </div>

            <!-- button tambah   -->
            <div class="container text-center mt-3">
                <div class="text-dark pt-3">
                    <?php if (session()->getFlashdata('pesan')) : ?>
                        <div class="alert alert-succes" role="alert">
                            <?= session()->getFlashdata('pesan'); ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            <!-- daftar pemasok -->
            <div class="container text-center pt-5 pb-5">
                <div class="row ms-5 me-5">
                    <div class="col pb-3">
                        <div class="container">
                            <div class="card text-center">
                                <div class="card-body bg-dark">
                                    <table class="table bg-dark text-light" border="1">
                                        <thead>
                                            <tr class="text-light">
                                                <th scope="col">Kode Pemasok</th>
                                                <th scope="col">Nama Pemasok</th>
                                                <th scope="col">Jenis Barang</th>
                                                <th scope="col">Aksi</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $i = 1;
                                            foreach ($Pemasok as $p) :
                                            ?>
                                                <tr class="text-light">
                                                    <td><?= $p['id_pemasok']; ?></td>
                                                    <td><?= $p['nama_pemasok']; ?></td>
                                                    <td><?= $p['jenis_barang']; ?></td>
                                                    <td>
                                                        <a href="/pemasok/<?= $p['id_pemasok']; ?>" class="btn btn-success">Detail</a>
                                                        <a href="/Pemasok/ubah/<?= $p['id_pemasok']; ?>" class="btn btn-primary">Ubah</a>
                                                        <form action="/Pemasok/<?= $p['id_pemasok']; ?>" method="post" class="d-inline">
                                                            <?= csrf_field(); ?>
                                                            <input type="hidden" name="_method" value="DELETE">
                                                            <button type="submit" class="btn btn-danger" onclick="return confirm('Yakin Mau Menghapus Data Ini !!!')">Hapus</button>
                                                        </form>
                                                    </td>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div><br><br>
                        </div>
                    </div>
                </div>
            </div>
            <?php $this->endSection(); ?>