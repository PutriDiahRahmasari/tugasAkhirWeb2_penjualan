+++
title = "Getting started"
description = ""
weight = 10
alwaysopen = true
+++

Pdfmake is runnable in browser (client-side) and in Node.js (server-side). Usages are described in next chapters.