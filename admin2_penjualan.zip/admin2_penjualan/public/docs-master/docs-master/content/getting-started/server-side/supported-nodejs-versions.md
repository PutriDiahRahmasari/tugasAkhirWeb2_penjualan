+++
title = "Supported Node.js versions"
description = ""
weight = 11
alwaysopen = true
+++

* 14 LTS (End-of-life: April 2023)
* 16 LTS (End-of-life: April 2024)
* 18 LTS (End-of-life: April 2025)