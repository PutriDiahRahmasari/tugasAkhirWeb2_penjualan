+++
title = "Examples"
description = ""
weight = 13
alwaysopen = true
+++

see [examples](https://github.com/bpampuch/pdfmake/tree/master/examples) and [dev-playground server script](https://github.com/bpampuch/pdfmake/blob/master/dev-playground/server.js)