+++
title = "Examples"
description = ""
weight = 12
alwaysopen = true
+++

Check out [the playground](http://bpampuch.github.io/pdfmake/playground.html) and [examples](https://github.com/bpampuch/pdfmake/tree/master/examples).