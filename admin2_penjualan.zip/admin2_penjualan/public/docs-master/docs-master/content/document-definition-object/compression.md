+++
title = "Compression"
description = ""
weight = 296
alwaysopen = true
+++

Compression of PDF is enabled by default, use `compress: false` for disable:

```js
var docDefinition = {
  compress: false,

  content: (...)
};
```