+++
title = "Custom fonts (client-side)"
description = ""
weight = 15
alwaysopen = true
+++

pdfmake uses the Roboto font by default. This guide explains how to use your own fonts with pdfmake (in client-side code).

## Two ways are now possible:
* [use virtual file system](/docs/0.3/fonts/custom-fonts-client-side/vfs/)
* [use font file via URL (https:// or http:// protocol)](/docs/0.3/fonts/custom-fonts-client-side/url/)
