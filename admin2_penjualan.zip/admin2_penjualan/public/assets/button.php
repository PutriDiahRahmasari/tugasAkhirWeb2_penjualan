<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">

</head>
<body>
       <!-- tampilan warna body -->
       <div class="bg-dark">
        <div class="container text-center pt-5">
            <div class="row">
                <div class="col">
                    <img src="/Images/user.png" alt="" width="15%" />
                    <h2 class="text-light pt-3">Daftar Barang</h2>
                </div>
            </div>
        </div>
    
        <!-- button tambah   -->
        <div class="container text-center mt-3">
            <a href="/barang/tambah" class="btn btn-primary">Tambahkan Data</a>
            <div class="text-light pt-3">
                <?php if (session()->getFlashdata('pesan')) : ?>
                    <div class="alert alert-succes" role="alert">
                        <?= session()->getFlashdata('pesan'); ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        <!-- daftar barang -->
        <?php
        foreach ($barang as $b) :
        ?>
            <div class="container text-center pt-5 pb-5">
                <div class="row ms-5 me-5">
                    <div class="col">
                        <div class="container">
                            <div class="card text-center">
                                <div class="card-header bg-warning"><?= $b['kd_barang']; ?></div>
                                <div class="card-body">
                                    <table class="table" border="0">
                                        <tr>
                                            <td>
                                                <img src="/img/<?= $b['gambar']; ?>" alt="" width="75">
                                            </td>
                                            <td>
                                                <h5 class="card-title pt-20"><?= $b['nama']; ?></h5>
                                                <p class="card-text">Harga Barang :<?= $b['harga']; ?></p>
                                                <p class="card-text">Satuan : <?= $b['satuan']; ?></p>
                                                <p class="card-text">Stok : <?= $b['stok']; ?></p>
                                            </td>
                                        </tr>
                                    </table>
                                </div>
                                <div class="card-footer text-body-secondary bg-warning"><a href="/barang/ubah/<?= $b['kd_barang']; ?>" class="btn btn-primary">Ubah</a>
                                    <form action="/barang/<?= $b['kd_barang']; ?>" method="post" class="d-inline">
                                        <?= csrf_field(); ?>
                                        <input type="hidden" name="_method" value="DELETE">
                                        <button type="submit" class="btn btn-danger" onclick="return confirm('Yakin Mau Menghapus Data Ini !!!')">Hapus</button>
                                    </form>
                                </div>
                            </div>
                        </div><br><br>
                    </div>
                </div>
            </div>
    
        <?php endforeach; ?>
        <!-- end daftar pelanggan -->
    </div>
    </div>
    </div>
</body>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>

</html>